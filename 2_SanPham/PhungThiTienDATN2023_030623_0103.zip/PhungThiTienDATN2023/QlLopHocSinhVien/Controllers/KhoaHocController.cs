﻿using Microsoft.AspNetCore.Mvc;
using QlLopHocSinhVien.Model.Entities;
using QlLopHocSinhVien.Service;

namespace QlLopHocSinhVien.Controllers
{
    public class KhoaHocController : Controller
    {
        private readonly IKhoaHocService _KhoaHocService;
        public KhoaHocController(IKhoaHocService KhoaHocService)
        {
            _KhoaHocService = KhoaHocService;
        }
        public IActionResult Index()
        {
            IEnumerable<KhoaHoc> result = _KhoaHocService.GetAllKhoaHoc();
            return View(result);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(KhoaHoc KhoaHoc)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _KhoaHocService.InsertKhoaHoc(KhoaHoc);
                    return Redirect("/KhoaHoc/Index");

                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);

            }
            return View(KhoaHoc);

        }
        [HttpGet]
        public IActionResult Edit(string id)
        {
            KhoaHoc KhoaHoc = _KhoaHocService.GetKhoaHoc(id);
            if (KhoaHoc != null)
            {
                return View(KhoaHoc);
            }
            return View();
        }
        [HttpPost]
        public IActionResult Edit(KhoaHoc KhoaHoc)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _KhoaHocService.UpdateKhoaHoc(KhoaHoc);
                    return Redirect("/KhoaHoc/Index");
                }
            }
            catch (Exception ex)
            {

                ModelState.AddModelError(string.Empty, ex.Message);
            }
            return View(KhoaHoc);
        }
        public IActionResult Delete(string id)
        {
            _KhoaHocService.DeleteKhoaHoc(id);
            return Redirect("/KhoaHoc/Index");
        }


        [HttpGet]
        public IActionResult Search(string name)
        {

            IEnumerable<KhoaHoc> result = _KhoaHocService.GetAllKhoaHoc();
            if (!string.IsNullOrEmpty(name))
            {
                result = result.Where(x => x.TieuDe.Contains(name));

            }
           
            return View(result);
        }
    }
}
