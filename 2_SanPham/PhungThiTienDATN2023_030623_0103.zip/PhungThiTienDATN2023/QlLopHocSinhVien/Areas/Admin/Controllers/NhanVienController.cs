﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.DotNet.Scaffolding.Shared.Messaging;
using QlLopHocSinhVien.Model.Entities;
using QlLopHocSinhVien.Models;
using QlLopHocSinhVien.Service;

namespace QlLopHocSinhVien.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class NhanVienController : Controller
    {
        private INhanVienService nhanVienService;
        private IPhongBanService phongBanService;
        private IChucVuService chucVuService;
        private ITaiKhoanService taiKhoanService;

        public NhanVienController(INhanVienService nhanVienService, IPhongBanService phongBanService, IChucVuService chucVuService, ITaiKhoanService taiKhoanService)
        {
            this.nhanVienService = nhanVienService;
            this.phongBanService = phongBanService;
            this.chucVuService = chucVuService;
            this.taiKhoanService = taiKhoanService;
        }

        public IActionResult Index()
        {
            var listNV = nhanVienService.GetAllNhanVien();
            return View(listNV);
        }

        public IActionResult Create()
        {
            var listPhongBan = phongBanService.GetAllPhongBan().ToList();
            ViewBag.PhongBan = new SelectList(phongBanService.GetAllPhongBan(), "MaPb", "TenPb");
            ViewBag.ChucVu = new SelectList(chucVuService.GetAllChucVu(), "MaCv", "TenCv");

            return View();
        }
        public IActionResult Edit(string id)
        {
            NhanVien nhanVien = nhanVienService.GetAllNhanVien().FirstOrDefault(x => x.MaNv == id);
            if (nhanVien != null)
            {
                TaiKhoan taiKhoan = taiKhoanService.GetAllTaiKhoan().FirstOrDefault(x => x.MaTaiKhoan == nhanVien.MaTaiKhoan);


                ViewBag.TenTaiKhoan = taiKhoan == null ? "" : taiKhoan.TenTaiKhoan;
                ViewBag.MatKhau = taiKhoan == null ? "" : MaHoaMD5.DecryptPassword(taiKhoan.MatKhau);
            }

            return View(nhanVien);
        }
        public IActionResult Delete(string id)
        {
            try
            {
                NhanVien nhanVien = nhanVienService.GetAllNhanVien().FirstOrDefault(x => x.MaNv == id);
                if (nhanVien != null)
                {
                    nhanVienService.DeleteNhanVien(id);
                }


                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
        public IActionResult About() { return View(); }


        [HttpPost]
        public IActionResult Create(NhanVien employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    nhanVienService.InsertNhanVien(employee);

                    return RedirectToAction("Index");
                }

                return View(employee);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Edit(NhanVien employee, string id, string username, string password)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var account = taiKhoanService.GetAllTaiKhoan().Where(x => x.TenTaiKhoan == username && x.MaTaiKhoan != id).FirstOrDefault();
                    if (account == null)
                    {
                        TaiKhoan taiKhoan = taiKhoanService.GetAllTaiKhoan().FirstOrDefault(x => x.MaTaiKhoan == id);
                        if (taiKhoan == null)
                        {
                            taiKhoan = new TaiKhoan();

                            taiKhoan.MaTaiKhoan = id;
                            taiKhoan.TenTaiKhoan = username;
                            taiKhoan.MatKhau = MaHoaMD5.EncryptPassword(password);

                            taiKhoanService.InsertTaiKhoan(taiKhoan);
                        }
                        else
                        {
                            taiKhoan.MaTaiKhoan = id;
                            taiKhoan.TenTaiKhoan = username;
                            taiKhoan.MatKhau = MaHoaMD5.EncryptPassword(password);

                            taiKhoanService.UpdateTaiKhoan(taiKhoan);
                        }

                        employee.MaTaiKhoan = taiKhoan.MaTaiKhoan;
                        nhanVienService.UpdateNhanVien(employee);

                        return RedirectToAction("Index");

                    }
                    else
                    {
                        ViewBag.Message = "Tên tài khoản đã được sử dụng!";
                    }


                }

                return View(employee);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
    }
}
