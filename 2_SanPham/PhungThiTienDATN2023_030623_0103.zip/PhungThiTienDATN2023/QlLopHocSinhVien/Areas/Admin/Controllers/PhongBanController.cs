﻿using Microsoft.AspNetCore.Mvc;
using QlLopHocSinhVien.Model.Entities;
using QlLopHocSinhVien.Service;

namespace QlLopHocSinhVien.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class PhongBanController : Controller
    {
        private IPhongBanService phongBanService;

        public PhongBanController(IPhongBanService phongBanService)
        {
            this.phongBanService = phongBanService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create() { return View(); }
        public IActionResult Edit() { return View(); }
        public IActionResult Delete() { return View(); }

        [HttpPost]
        public IActionResult Create(PhongBan phongBan)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    phongBanService.InsertPhongBan(phongBan);

                    return RedirectToAction("Index");
                }

                return View(phongBan);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
    }
}
