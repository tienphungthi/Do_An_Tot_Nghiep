﻿using Microsoft.AspNetCore.Mvc;

namespace QlLopHocSinhVien.Controllers
{
    public class DangKiHocController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
