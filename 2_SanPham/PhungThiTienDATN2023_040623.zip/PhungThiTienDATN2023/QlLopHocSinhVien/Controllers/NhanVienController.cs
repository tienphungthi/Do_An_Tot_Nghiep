﻿using Microsoft.AspNetCore.Mvc;

namespace QlLopHocSinhVien.Controllers
{
	public class NhanVienController : Controller
	{
		public IActionResult Index()
		{
			return View();
		}
	}
}
